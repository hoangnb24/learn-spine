# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: gate.spec.ts >> Gate2 ik authored and measured
- Location: tests/e2e/deformation/gate.spec.ts:33:51

# Error details

```
Error: expect(received).toBeCloseTo(expected, precision)

Expected: 1.9999999999999991
Received: 0

Expected precision:    8
Expected difference: < 0.000000005
Received difference:   1.9999999999999991

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "learn-spine, về Editor" [ref=e5] [cursor=pointer]:
      - /url: ./index.html
      - generic [aria-hidden] [ref=e6]: ◇
      - text: learn-spine
      - generic [ref=e7]: / Player
    - navigation "Ứng dụng" [ref=e8]:
      - link "Editor" [ref=e9] [cursor=pointer]:
        - /url: ./index.html
      - link "Player" [ref=e10] [cursor=pointer]:
        - /url: ./player.html
    - generic [ref=e11]: Không gian sáng tạo 2D
  - generic [ref=e12]:
    - generic [ref=e13] [cursor=pointer]:
      - text: Mở gói project
      - button "Mở gói project" [ref=e14]
    - generic [ref=e15]: Gate2 ik
  - main "Player" [ref=e16]:
    - generic [ref=e19]:
      - button "Vừa khung" [ref=e20] [cursor=pointer]
      - generic [ref=e21]:
        - text: Thu phóng
        - combobox "Thu phóng" [ref=e22]:
          - option "50%"
          - option "100%" [selected]
          - option "200%"
  - generic [ref=e23]:
    - combobox "Chọn chuyển động" [ref=e24]:
      - option "Tư thế Setup"
      - option "Cycle" [selected]
    - button "Phát" [active] [ref=e25] [cursor=pointer]
    - slider "Thanh thời gian" [ref=e26]: "2"
    - status [ref=e27]: 2.00 s
  - contentinfo [ref=e28]:
    - generic [ref=e29]: Player
    - generic [ref=e30]: Bản 3 · 3 ảnh trong gói
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {mkdirSync,writeFileSync} from 'node:fs';
  3  | import {resolve} from 'node:path';
  4  | import {execFileSync} from 'node:child_process';
  5  | const run=process.env.GATE2_RUN??'run-01';
  6  | const output=resolve('../docs/product/results/experiment-2',run);
  7  | mkdirSync(output,{recursive:true});
  8  | const save=(name:string,value:unknown)=>writeFileSync(resolve(output,name),JSON.stringify(value,null,2));
  9  | async function instrument(page:Page){await page.evaluate(async()=>{
  10 |  const path='/src/render/index.ts';const{PixiRenderer}=await import(/* @vite-ignore */path);
  11 |  const state:any={latest:null,playback:false,perf:false,poses:[],draws:[]};(window as any).__gate2=state;
  12 |  const original=PixiRenderer.prototype.draw;
  13 |  PixiRenderer.prototype.draw=function(pose:any,viewport:any){const start=performance.now(),result=original.call(this,pose,viewport),end=performance.now();
  14 |  if(state.perf)state.draws.push({start,end,cpuMs:end-start,time:pose.sampledTime});
  15 |  else {state.latest={pose:structuredClone(pose),viewport,ok:result.ok};if(state.playback)state.poses.push({at:start,pose:structuredClone(pose),ok:result.ok});}return result;};
  16 |  });await page.addStyleTag({content:'.stage{width:1280px!important;height:720px!important;flex:none!important;min-width:1280px!important;min-height:720px!important}'});}
  17 | async function drawn(page:Page){return page.evaluate(()=>(window as any).__gate2.latest);}
  18 | async function seek(page:Page,app:'editor'|'player',time:number){if(app==='editor')await page.getByLabel('Thời gian (giây)',{exact:true}).fill(String(time));else await page.getByLabel('Thanh thời gian',{exact:true}).evaluate((node:any,value)=>{node.step='any';Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')!.set!.call(node,String(value));node.dispatchEvent(new Event('input',{bubbles:true}));node.dispatchEvent(new Event('change',{bubbles:true}));},time);
> 19 |  await expect.poll(async()=>(await drawn(page))?.pose.sampledTime).toBeCloseTo(time===2?0:time,8);return drawn(page);}
     |                                                                    ^ Error: expect(received).toBeCloseTo(expected, precision)
  20 | const numbers=(p:any)=>[...Object.values(p.bones).flat(),...p.meshes.flatMap((m:any)=>m.vertices),...p.regions.flatMap((r:any)=>r.world)] as number[];
  21 | function delta(a:any,b:any){const av=numbers(a),bv=numbers(b);expect(av.length).toBe(bv.length);return Math.max(0,...av.map((n,i)=>Math.abs(n-bv[i])));}
  22 | async function playback(page:Page,app:'editor'|'player',kind:string){await seek(page,app,0);await page.evaluate(()=>{const s=(window as any).__gate2;s.playback=true;s.poses=[];});await page.getByRole('button',{name:'Phát',exact:true}).click();await page.waitForTimeout(6500);await page.getByRole('button',{name:'Tạm dừng',exact:true}).click();const frames=await page.evaluate(()=>{const s=(window as any).__gate2;s.playback=false;return s.poses;});
  23 |  save(`${kind}-${app}-playback.json`,frames);expect(frames.length).toBeGreaterThan(120);expect(frames.every((f:any)=>f.ok)).toBe(true);
  24 |  const wraps=frames.filter((f:any,i:number)=>i>0&&f.pose.sampledTime<frames[i-1].pose.sampledTime);expect(wraps.length).toBeGreaterThanOrEqual(3);
  25 |  // First forward cycle is an actual successful draw stream, not evaluator snapshots.
  26 |  const first=frames.slice(0,frames.indexOf(wraps[0])).filter((f:any)=>f.pose.sampledTime>0);
  27 |  const indices=[7,1,15,3,19,0,12,5,17,9,2,14,6,18,10,4,16,8,13,11];const comparisons=[];
  28 |  for(const index of indices){const ref=first[Math.floor(index*(first.length-1)/19)],actual=await seek(page,app,ref.pose.sampledTime);comparisons.push({time:ref.pose.sampledTime,delta:delta(ref.pose,actual.pose)});}
  29 |  save(`${kind}-${app}-seeks.json`,comparisons);expect(Math.max(...comparisons.map(c=>c.delta))).toBeLessThanOrEqual(1e-5);return{frames:frames.length,wraps:wraps.length,comparisons};}
  30 | async function perf(page:Page,app:string,kind:string){await page.getByRole('button',{name:'Phát',exact:true}).click();await page.waitForTimeout(5000);const raw=await page.evaluate(()=>new Promise<any>(resolve=>{const s=(window as any).__gate2;s.draws=[];s.perf=true;const start=performance.now(),raf:number[]=[];function tick(now:number){raf.push(now);if(now-start<30000)requestAnimationFrame(tick);else{s.perf=false;const c=document.querySelector('canvas')!,gl=(c.getContext('webgl2')||c.getContext('webgl')) as WebGLRenderingContext,ext=gl.getExtension('WEBGL_debug_renderer_info');resolve({start,end:performance.now(),raf,draws:s.draws,canvas:[c.width,c.height],gpu:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):'unavailable',userAgent:navigator.userAgent,visibility:document.visibilityState});}}requestAnimationFrame(tick);}));await page.getByRole('button',{name:'Tạm dừng',exact:true}).click();
  31 |  const intervals=(a:number[])=>a.slice(1).map((n,i)=>n-a[i]),p95=(a:number[])=>a.slice().sort((a,b)=>a-b)[Math.ceil(a.length*.95)-1];const summary={duration:raw.end-raw.start,frames:raw.draws.length,p95RafIntervalMs:p95(intervals(raw.raf)),p95DrawIntervalMs:p95(intervals(raw.draws.map((d:any)=>d.start))),p95CpuSubmissionMs:p95(raw.draws.map((d:any)=>d.cpuMs)),physicalPresentation:'unavailable',performanceGate:'not specified for Gate2; report only',instrumentation:'draw timing excludes cloning; record numeric timestamps only; screenshots/sequence/encoding outside window; browser video active'};
  32 |  save(`${kind}-${app}-performance.json`,{summary,raw});expect(raw.canvas).toEqual([1280,720]);return summary;}
  33 | for(const kind of ['scarf','jelly','ik'] as const)test(`Gate2 ${kind} authored and measured`,async({page,browser})=>{
  34 |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/tests/e2e/deformation/index.html');await instrument(page);
  35 |  const project=await page.evaluate(kind=>window.gate2.author(kind),kind);save(`${kind}-project.json`,project);
  36 |  await expect(page.locator('.stage')).toHaveAttribute('data-rendered-revision',String(project.revision));
  37 |  const measured=await page.evaluate(()=>window.gate2.measure());save(`${kind}-measurements.json`,measured);
  38 |  expect.soft(measured.report.passed,JSON.stringify(measured.report)).toBe(true);
  39 |  if(measured.eyes){const errors=measured.eyes.samples.flatMap(s=>s.map((eye,i)=>Math.abs(eye.height/measured.eyes!.canonical[i].height-1)));save('jelly-eye-heights.json',{maxRelativeChange:Math.max(...errors),errors});expect.soft(Math.max(...errors)).toBeLessThanOrEqual(.05);}
  40 |  const sequences=await page.evaluate(()=>window.gate2.sequence());const seqdir=resolve(output,`${kind}-sequence`);mkdirSync(seqdir,{recursive:true});for(const[f,frame]of sequences.frames.entries())writeFileSync(resolve(seqdir,`${String(f).padStart(3,'0')}.png`),Buffer.from(frame.png.split(',')[1],'base64'));save(`${kind}-sequence.json`,{view:sequences.view,times:sequences.frames.map(f=>f.time)});
  41 |  const zip=resolve(output,`${kind}.zip`),downloaded=page.waitForEvent('download');await page.getByRole('button',{name:'Tải gói project',exact:true}).click();await(await downloaded).saveAs(zip);
  42 |  const playbackResult=await playback(page,'editor',kind);await page.screenshot({path:resolve(output,`${kind}-editor.png`)});
  43 |  const perfResult=await perf(page,'editor',kind);
  44 |  const half=await page.evaluate(async()=>{const h=window.gate2,before=h.runtime.session!.inspect(),after=await h.replaceHalf(),measure=await h.measure();return{before,after,measure,equal:JSON.stringify(h.semantics(before))===JSON.stringify(h.semantics(after))};});save(`${kind}-half.json`,half);expect(half.equal).toBe(true);for(let i=0;i<measured.samples.length;i++)expect(delta(measured.samples[i],half.measure.samples[i])).toBe(0);
  45 |  const halfSeq=await page.evaluate(()=>window.gate2.sequence(true));for(const i of [0,15,30,45,60]){const frame=halfSeq.frames[i];if(frame)writeFileSync(resolve(output,`${kind}-half-${i}.png`),Buffer.from(frame.png.split(',')[1],'base64'));}
  46 |  const hd=page.waitForEvent('download');await page.getByRole('button',{name:'Tải gói project',exact:true}).click();await(await hd).saveAs(resolve(output,`${kind}-half.zip`));
  47 |  // Close original editor; fresh page imports exported full ZIP.
  48 |  await page.close();const reopened=await browser.newPage();await reopened.goto('/tests/e2e/deformation/index.html');await instrument(reopened);await reopened.getByLabel('Mở gói project',{exact:true}).setInputFiles(zip);await expect.poll(()=>reopened.evaluate(()=>window.gate2.runtime.session?.inspect())).toEqual(project);await reopened.close();
  49 |  const context=await browser.newContext({viewport:{width:1900,height:1300},deviceScaleFactor:1,recordVideo:{dir:resolve(output,'player-videos')}}),player=await context.newPage();const requests:string[]=[];player.on('request',r=>requests.push(r.url()));player.on('pageerror',e=>errors.push(e.message));await player.goto('http://127.0.0.1:4196/player.html');await instrument(player);await player.getByLabel('Mở gói project',{exact:true}).setInputFiles(zip);await expect(player.locator('.stage')).toHaveAttribute('data-rendered-revision',String(project.revision));
  50 |  const playerSamples=[];for(const time of [0,.25,.5,.75,1,1.25,1.5,1.75]){const actual=await seek(player,'player',time);const ref=measured.samples.find(p=>Math.abs(p.sampledTime-time)<1e-8);if(ref)expect(delta(ref,actual.pose)).toBeLessThanOrEqual(1e-5);playerSamples.push(actual);}
  51 |  const playerPlayback=await playback(player,'player',kind);await player.screenshot({path:resolve(output,`${kind}-player.png`)});const playerPerf=await perf(player,'player',kind);expect(requests.filter(u=>/apps\/editor|exercises\//.test(u))).toEqual([]);expect(errors).toEqual([]);
  52 |  save(`${kind}-result.json`,{sourceCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),protocolCommit:'d836e8c87c5a8a095d9e5761ff87ef6991f7e7b6',browser:browser.version(),classification:'public commands + browser UI; no native WebMCP claim',playbackResult,perfResult,playerPlayback,playerPerf,playerSamples,requests,errors,physics:'NOT TESTED'});await context.close();
  53 | });
  54 | 
```